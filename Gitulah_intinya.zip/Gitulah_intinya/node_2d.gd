extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

func _physics_process(delta: float) -> void:
	if Input.is_action_pressed("ui_right"):
		$Ralsei.move_and_collide(Vector2(15,0))
	if Input.is_action_pressed("ui_left"):
		$Ralsei.move_and_collide(Vector2(-15,0))
	if Input.is_action_pressed("ui_up"):
		$Ralsei.move_and_collide(Vector2(0,-15))
	if Input.is_action_pressed("ui_down"):
		$Ralsei.move_and_collide(Vector2(0,15))
	
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta: float) -> void:
#	if Input.is_action_pressed("ui_right"):
#		$Ralsei.position += Vector2(5,0)
#	if Input.is_action_pressed("ui_left"):
#		$Ralsei.position += Vector2(-5,0)
#	if Input.is_action_pressed("ui_up"):
#		$Ralsei.position += Vector2(0,-5)
#		$Ralsei.position += Vector2(0,5)
#	pass

func _kalo_masuk(body: Node2D) -> void:
	print("Yada Yada")
	pass # Replace with function body.


func _kalo_keluar(body: Node2D) -> void:
	print("Come back, Baby boyyy")
	pass # Replace with function body.


func _on_area_2d_2_body_entered(body: Node2D) -> void:
	print("Yada Yada")
	pass # Replace with function body.


func _on_area_2d_2_body_exited(body: Node2D) -> void:
	print("Come back, Baby boyyy")
	pass # Replace with function body.
