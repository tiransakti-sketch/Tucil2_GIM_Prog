extends Node2D

const SPEED = 400.0 # Pixels per second

func _process(delta: float) -> void:
	if Input.is_action_pressed("ui_right"):
		$Kucing.position.x += SPEED * delta
		print("Ke Kanan")
